import React from 'react';
import Navbar from './components/Navbar';
import AboutHero from './components/AboutHero';
import AboutContent from './components/AboutContent';
import Footer from './components/Footer';
import ScrollProgress from './components/ScrollProgress';

const AboutPage = () => {
  return (
    <div className="relative min-h-screen bg-[#1a1a1a] text-white overflow-x-hidden">
      {/* Noise texture overlay */}
      <div
        className="fixed inset-0 opacity-[0.025] pointer-events-none z-50"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
          backgroundSize: '256px 256px',
        }}
        aria-hidden="true"
      />

      <ScrollProgress />
      <Navbar activePage="about" />
      <main>
        <AboutHero />
        <AboutContent />
      </main>
      <Footer />
      
    </div>
  );
};

export default AboutPage;
