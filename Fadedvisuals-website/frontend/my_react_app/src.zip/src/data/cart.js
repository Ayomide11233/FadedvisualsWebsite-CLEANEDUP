/* ═══════════════════════════════════════════════════════════
   CART DATA
   Mock cart items for demonstration
═══════════════════════════════════════════════════════════ */

export const MOCK_CART_ITEMS = [
  {
    id: 'cart-1',
    productId: 'celestial-chaos',
    title: 'Celestial Chaos',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800&q=80',
    price: 20,
    size: 'M',
    frame: 'Gold',
    quantity: 1,
  },
  {
    id: 'cart-2',
    productId: 'ethereal-gaze',
    title: 'Ethereal Gaze',
    image: 'https://images.unsplash.com/photo-1561214115-f2f134cc4912?w=800&q=80',
    price: 20,
    size: 'L',
    frame: 'Black',
    quantity: 2,
  },
  {
    id: 'cart-3',
    productId: 'midnight-bloom',
    title: 'Midnight Bloom',
    image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=800&q=80',
    price: 20,
    size: 'S',
    frame: 'No Frame',
    quantity: 1,
  },
];

export const SHIPPING_COST = 12.99;
export const FREE_SHIPPING_THRESHOLD = 75;
