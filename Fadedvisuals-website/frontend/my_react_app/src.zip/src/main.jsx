import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

const path = window.location.pathname;

const renderPage = async () => {
  let Component;

  if (path === '/about' || path === '/about.html') {
    const mod = await import('./AboutPage.jsx');
    Component = mod.default;
  } else if (path === '/services' || path === '/services.html') {
    const mod = await import('./ServicePage.jsx');
    Component = mod.default;
  } else if (path === '/shop' || path === '/shop.html') {
    const mod = await import('./ShopPage.jsx');
    Component = mod.default;
  } else if (path === '/cart' || path === '/cart.html') {
    const mod = await import('./CartPage.jsx');
    Component = mod.default;
  } else if (path.startsWith('/shop/')) {
    const mod = await import('./ProductDetailPage.jsx');
    Component = mod.default;
  } else {
    const mod = await import('./App.jsx');
    Component = mod.default;
  }

  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <Component />
    </React.StrictMode>
  );
};

renderPage();
